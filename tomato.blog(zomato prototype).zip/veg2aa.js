function placeOrder() {
    alert("Your order has been placed. It will be delivered soon.");
    window.location.href = "home.html";
}
