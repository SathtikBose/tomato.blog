function handleLogin(event) {
    event.preventDefault(); 
    window.location.href = 'home.html';
}

